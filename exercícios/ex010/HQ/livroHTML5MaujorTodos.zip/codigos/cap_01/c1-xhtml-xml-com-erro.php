﻿<?php header('Content-Type: application/xhtml+xml'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Página XHTML</title>
	<style type="text/css" media="all">
		/* regras de estilo */
	</style>
</head>
<body>
	<h1>Página com marcação XHTML</h1>
		<p>Essa página contém marcação XHTML <strong class=destaque>com erros</strong></p>
		<p>Foi servida com tipo de MIME <code>application/xhtml+xml</code></p> 
</body>
</html>
