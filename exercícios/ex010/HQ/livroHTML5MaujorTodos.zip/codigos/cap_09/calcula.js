var r=0;
for(i=0; i<=1e+9; i++) {r += i;} 
postMessage(r);	
